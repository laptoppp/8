package com.example.application5;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHandler db;
    EditText rollNo, name, course, sem;
    RadioButton insert, update, delete, viewDatabase;
    TextView display;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        db = new DatabaseHandler(this);
        Toast.makeText(this, "Database created Successfully !", Toast.LENGTH_SHORT).show();

        button = findViewById(R.id.button);

        rollNo = findViewById(R.id.rollNo);
        name = findViewById(R.id.name);
        course = findViewById(R.id.course);
        sem = findViewById(R.id.sem);

        insert = findViewById(R.id.insert);
        update = findViewById(R.id.update);
        delete = findViewById(R.id.delete);
        viewDatabase = findViewById(R.id.view);

        display = findViewById(R.id.display);
        display.setVisibility(View.GONE);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void performAction(View view) {

        if(button.getText().equals("Insert"))
            insert.setChecked(true);
        else if(button.getText().equals("Update"))
            update.setChecked(true);
        else if(button.getText().equals("Delete"))
            delete.setChecked(true);

        if (insert.isChecked()) {

            if(validate()) {
                int r = Integer.parseInt(rollNo.getText().toString().trim());
                String n = name.getText().toString().trim();
                String c = course.getText().toString().trim();
                int s = Integer.parseInt(sem.getText().toString().trim());

                boolean result = db.insert(r, n, c, s);
                if(result)
                    Toast.makeText(getApplicationContext(), "Data Successfully Inserted!", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(), "Data Insertion Failed!", Toast.LENGTH_LONG).show();
            }
        }
        else if(update.isChecked()) {
            if (validate()) {
                int r = Integer.parseInt(rollNo.getText().toString().trim());
                String n = name.getText().toString().trim();
                String c = course.getText().toString().trim();
                int s = Integer.parseInt(sem.getText().toString().trim());

                if(db.update(r, n, c, s) != 0)
                    Toast.makeText(getApplicationContext(), "Data Successfully Updated!", Toast.LENGTH_LONG).show();
            }
        }
        else if(delete.isChecked()) {
            int r = 0;
            if (rollNo.getText().toString().trim().length() != 0) {
                r = Integer.parseInt(rollNo.getText().toString().trim());
                if(db.delete(r) != 0)
                    Toast.makeText(getApplicationContext(), "Data Successfully Deleted!", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void setView(View view) {

        switch (view.getId()) {
            case R.id.insert:
                rollNo.setVisibility(View.VISIBLE);
                name.setVisibility(View.VISIBLE);
                course.setVisibility(View.VISIBLE);
                sem.setVisibility(View.VISIBLE);
                button.setText("Insert");
                break;
            case R.id.delete:
                rollNo.setVisibility(View.VISIBLE);
                name.setVisibility(View.GONE);
                course.setVisibility(View.GONE);
                sem.setVisibility(View.GONE);
                button.setText("Delete");
                break;
            case R.id.update:
                rollNo.setVisibility(View.VISIBLE);
                name.setVisibility(View.VISIBLE);
                course.setVisibility(View.VISIBLE);
                sem.setVisibility(View.VISIBLE);
                button.setText("Update");
                break;
            case R.id.view:
                Cursor c = db.viewRecords();
                StringBuilder sb = new StringBuilder();

                if(c.moveToFirst()) {
                    do {
                        sb.append(c.getInt(0) + "\t\t\t\t\t" + c.getString(1) + "\t\t\t\t\t" + c.getString(2) + "\t\t\t\t\t" + c.getString(3) +"\n");
                    }
                    while(c.moveToNext());
                }
                display.setText(sb);
                display.setVisibility(View.VISIBLE);
                if(sb.length() ==0)
                    Toast.makeText(getApplicationContext(), "No Records Found!", Toast.LENGTH_LONG).show();
                break;
        }

    }

    public boolean validate() {
        if (rollNo.getText().toString().trim().length() != 0 &&
            name.getText().toString().trim().length() != 0 &&
            course.getText().toString().trim().length() != 0 &&
            sem.getText().toString().trim().length() != 0 ) {
            return true;
        }
        else
            Toast.makeText(getApplicationContext(), "All Fields Required!", Toast.LENGTH_LONG).show();
        return false;
    }
}