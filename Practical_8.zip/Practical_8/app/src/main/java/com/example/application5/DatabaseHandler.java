package com.example.application5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

public class DatabaseHandler extends SQLiteOpenHelper {

    static String DB_NAME = "students.db";
    static int DB_VERSION = 1;
    Context context;
    private String query;

    public DatabaseHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        query = "CREATE TABLE records (rollNo INTEGER PRIMARY KEY , name TEXT, course TEXT, sem INTEGER)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean insert(int rollNo, String name, String course, int sem) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("rollNo", rollNo);
        values.put("name", name);
        values.put("course", course);
        values.put("sem", sem);

        long returnValue = db.insert("records", null, values);
        db.close();

        if(returnValue != -1)
            return true;
        else
            return false;
    }

    public int update(int rollNo, String name, String course, int sem) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("rollNo", rollNo);
        values.put("name", name);
        values.put("course", course);
        values.put("sem", sem);

        int returnValue = db.update("records", values ,"rollNo=?", new String[]{rollNo+""});
        return returnValue;

    }

    public int delete(int rollNo) {
        SQLiteDatabase db = getWritableDatabase();
        int returnValue = db.delete("records", "rollNo=?", new String[]{rollNo+""});
        return returnValue;
    }

    public Cursor viewRecords() {
        SQLiteDatabase db = getWritableDatabase();
        query = "SELECT * FROM records";
        Cursor c = db.rawQuery(query, null);

        return c;
    }
}
